
## From T-6 (2026-09-23)
- `wenget info <missing>` prints "Not found" to stderr but exits 0 (same for all-missing names). Candidate bug; not changed in T-6.

## User preference (2026-09-23)
- Do not ask about deleting /tmp sandboxes; the user will raise cleanup themselves.

## From OP-2 (2026-09-24)
- Machine reboot cleared /tmp: /tmp/wg-old baseline (rebuilt from d72cdb5 via worktree /tmp/wg-base), /tmp/wg-t3.q9Pu, and earlier sandboxes are gone (not deleted by the agent).
- Downloads have no total/read timeout (`utils::http::shared_client`, `downloader::download_file`): a stalled connection would hang `add` forever. Observed 2026-09-24: `add -y bun` ran 20+ min, but sampling showed the download still progressing at ~100 KB/s from the GitHub CDN (slow, not stalled). An idle/read timeout would only catch true stalls. Pre-existing (old downloader client had none either). Candidate: read/idle timeout on downloads.
- Variant names mis-parsed for `confy` on windows-x86_64: assets `confy-desktop-windows-x86_64.exe` / `confy-windows-x86_64.exe` yield variants `desktop-64` and `64` (arch `x86_64` split on `_`), so `--variant desktop` fails. Same in old and new binary (pre-existing). Candidate bug.
- cl8-transcripts.sh now takes MV_PKG / MV_VARIANT (default bun/baseline); small-package run: `MV_PKG="-p windows-x86_64 confy" MV_VARIANT=desktop`.

## Diagnoses (awaiting approval)
- B1 `info <missing>` exit 0: `commands/info.rs` `run` only prints "Error <name>: Not found" and returns Ok. Repro: exit=0. Plan: count misses, `bail!` at end if any name unresolved (after printing found items), like `add`. Test in tests/cli.rs.
- B2 variant mis-parse: `core/manifest.rs` `extract_variant_from_asset` turns `_` into `-` before matching, so `x86_64` becomes `x86-64` and never matches the `x86_64` patterns; `x86` then strips leaving `64`. Plan: normalize the patterns the same way (`pattern.replace('_', "-")`) + unit tests for confy assets. Risk: records already installed under `confy::64` / `confy::desktop-64` would no longer match on `update`. Options: (a) accept, (b) legacy fallback matching.
- B3 download idle timeout: NOT a bug. reqwest blocking applies the client default 30s timeout to the send and to each body `read` (`blocking::Response::read` -> `wait::timeout`). Stall server repro: fails after 30.02s. Optional: make it explicit in `shared_client` + a comment/test.
- P-3: plan pending.
- Cross-platform `-p windows-x86_64` install on macOS fails "Failed to find executable in archive" for a bare .exe (old binary too). Expected-ish (host cannot run it); not fixed.
- `list --all` prints scripts in HashMap order (random per run; packages are sorted). Pre-existing, cosmetic; candidate fix: sort scripts by name.
- B3 closed: no code change (reqwest blocking 30s default covers send + each body read).

## SI-10 (2026-09-23) — paused for user decision
- Corpus: all 1094 unique (package, asset) pairs in bucket/manifest.json → docs/tmp/claude-scratch/corpus.tsv;
  old outputs golden_old.tsv, candidate token parser golden_new.tsv, 343 differences in vdiff.tsv.
- Candidate parser (uncommitted, in `src/core/manifest.rs` test module `dump_new_tmp`): strip known
  extensions, strip repo prefix, split on `-`/`_`/`.`, drop numeric/`vN` tokens and OS/arch/ABI words.
- Compat risk: update mode feeds the installed record's `variant` back as the filter
  (`commands/add.rs` `effective_variant_filter`), and `installer::package` filters binaries by
  `extract_variant_from_asset(..) == filter`. Existing installs whose variant came from the old noisy
  parser (e.g. `Dar`, `apple`, `eabihf`) would no longer match on update.

## CL-6 follow-up (found during parity check)
- `del` group label and order are nondeterministic: `group_delete_candidates` labels a repo group
  with the first *matched key* (`bun::profile` or `bun`), and `match_installed` iterates the
  installed `HashMap`. Pre-existing (same in 934eede). Candidate fix: label with `repo_name`, sort
  matches. Needs bug-fix report/approval first.
- CL-6 covered the four named functions; other >100-LOC functions (e.g. `delete_self`,
  `install_scripts`, `install_from_urls`, `select_executables`) were left as is.
