#!/usr/bin/env bash
# Downloader benchmark: 4 connections (full install) vs 1 connection (120 s window), 3 rounds.
# Usage: bash docs/tmp/claude-scratch/dl-bench.sh   (from the repo root, after cargo build --release)
set -u
BIN=$PWD/target/release/wenget
U=https://github.com/hadolint/hadolint/releases/download/v2.15.1/hadolint-macos-arm64
SIZE=102616248
WINDOW=120
for r in 1 2 3; do
  R4=/tmp/wg-bench-4-$r; mkdir -p $R4; printf 'download_connections = 4\n' > $R4/config.toml
  S=$(date +%s)
  WENGET_ROOT=$R4 $BIN add -y $U > $R4/log 2>&1
  T=$(( $(date +%s) - S ))
  echo "round $r conn=4 full ${T}s => $(echo "scale=2; $SIZE/1048576/$T" | bc) MiB/s"

  R1=/tmp/wg-bench-1-$r; mkdir -p $R1; printf 'download_connections = 1\n' > $R1/config.toml
  WENGET_ROOT=$R1 $BIN add -y $U > $R1/log 2>&1 & P=$!
  sleep $WINDOW; kill -INT $P 2>/dev/null; wait $P
  B=$(stat -f %z $R1/cache/downloads/hadolint-macos-arm64.part 2>/dev/null || echo 0)
  echo "round $r conn=1 window ${WINDOW}s got $B bytes => $(echo "scale=2; $B/1048576/$WINDOW" | bc) MiB/s"
done
# Single-stream cross-run resume on the last 1-connection root
S=$(date +%s)
WENGET_ROOT=/tmp/wg-bench-1-3 $BIN add -y $U 2>&1 | tr '\r' '\n' | grep -E 'Resuming|Downloaded|Installed|Error'
echo "conn=1 resume to completion $(( $(date +%s) - S ))s"
shasum -a 256 /tmp/wg-bench-1-3/apps/hadolint/hadolint-macos-arm64
ls -A /tmp/wg-bench-1-3/cache/downloads/
