# Backlog triage — 2026-09-23 (HEAD 582aa40)

Six read-only scouts verified all 59 Open rows of `docs/plan/BACKLOG.md` against the tree; key claims
spot-checked by hand. Nothing below is applied to BACKLOG.md yet — pending user approval.

## Tier 1 — real bugs, cheap (XS–S)

| ID | Why | Platform | Effort |
|---|---|---|---|
| S-6 | `core/registry.rs` `modify_system_path_inner` writes `Path` back via `set_value(&String)` = REG_SZ; system PATH is REG_EXPAND_SZ, so `%SystemRoot%` entries stop expanding after admin `wenget init` | Windows admin | S |
| S-8 + Q-7 | `cmd /C start /B|/min <path>`: quoted path with spaces is taken as window title, script never runs (`update.rs` `replace_exe_windows`, `delete.rs` `delete_executable_windows`); same lines hold `.to_str().unwrap()` | Windows | XS |
| IM-13 | `config.rs` `detect_editor`/`run`: `Command::new("code --wait")` fails; `$VISUAL` ignored | all | XS |
| IM-7 | `core/config.rs` `Config::new` warns "using defaults" but keeps invalid prefs (confirmed) | all | XS |
| IM-6 | `add.rs` `record_installed` returns `()`; save failure still counted success, exit 0 | all | XS |
| B-1 | `repair.rs` `missing_shims` uses `exists()`; directory at `bin/<cmd>` reported healthy | all | XS |
| IM-10 | `add.rs` `install_package`: `remove_file(..).ok()` then prints "Removed" | all | XS |
| IM-14 | `input_detector.rs` `is_github_repo_url` = `contains("github.com")`; GitHub source tarballs / mirrors misrouted | all | XS |
| CL-4 | `preferences.rs` `generate_default_file` says user bin = `~/.wenget/bin`; code uses `~/.local/bin` | Unix | XS |
| CL-7 | `thiserror` unused (0 hits in src) | build | XS |
| CL-2 | `#[allow(dead_code)]` on live `Config::preferences`, `staging_dir`, `ScanEntry` | — | XS |

## Tier 2 — worth doing, moderate

| ID | Note | Effort |
|---|---|---|
| M-2 | `bucket/wenget` 4.5 MB tracked, re-committed each release; pack 15.9 MiB; only `update-manifest.yml` runs it | S |
| IM-8 | API path `inst != latest` vs cache path `is_newer_version`; API path offers downgrades (2.0.0→1.0.0) | S |
| IM-9 | `downloads/` archive leaks on any error after download (only final cleanup) | XS |
| IM-12 | `repair` reports missing launchers, never recreates | S |
| B-2 | `install_script_from_bucket` uses `custom_name.unwrap_or(name)`, ignores prior rename → needs real-binary repro first | S |
| S-4 + SI-5 | PowerShell PATH scripts interpolate `bin_dir` (apostrophe usernames break); dedupe init/delete PATH code together; delete never cleans system PATH | S |
| S-10 | release already publishes `SHA256SUMS`; `install.sh`/`install.ps1` never check it | S |
| S-9 | http:// accepted silently (warn, not reject, is the cheap variant) | XS |
| SI-3 | hand-rolled `glob_match`; `add 'x[12]*'` fails while `del` (uses `glob::Pattern`) works | XS |
| SI-8 / SI-9 / SI-4 | duplicate BucketCommand enum; 3× suffix loop in `resolve_command_name`; init copies `create_symlink` | XS each |
| SI-11 | 5 tally/summary blocks in add.rs → `BatchReport` | S |
| T-4 / T-5 | fake dedup test in delete.rs; zip extraction has zero tests | XS / S |
| M-5 | zip 0.6→2.x (`enclosed_name` API change, features); `is_elevated` unmaintained | M |

## Tier 3 — later (maintainability / negligible perf)

CL-1, CL-6, SI-6, SI-10 (golden tests mandatory first: output becomes on-disk key), SI-7, CL-3, CL-5,
A-6, A-7, OP-2, P-3, OP-3, OP-4, OP-5 (all perf < 3 ms vs seconds of network), T-2, T-3, T-6,
SI-12, Q-6, Q-9, IM-11, IM-15, S-7, S-5, B-3, B-4.

## Corrections to scout / backlog claims

- S-5: 0 packages in `bucket/manifest.json` carry `checksum` → manifest checksum is an unused future
  field, not "ignored data". Probe-failure downgrade is real but prints a warning. Lower to P3.
- S-7: bucket-controlled names can contain `$`/`"` (sanitizer strips only `/ \ ..`), but the same
  bucket already ships the script being executed → robustness, not a new trust boundary.
- SI-12: reqwest drops `Authorization` on cross-host redirects, so scout's S3-400 warning is overstated;
  still no user bug → later.
- B-4: `update self` was removed on purpose (`docs/plan/2026-03-18-update-scripts-and-self-check.md`);
  only the "'self' is not installed" warning is misleading.
- IM-15: bucket URLs are GitHub release URLs without query strings → no practical impact.
- Q-9: only matters when buckets.json is already corrupt AND backup fails.

## Close / drop

- A-4 → Done (3f56915 deleted `providers/base.rs`, 0 hits for `SourceProvider`).
- M-4 → Done (`CLAUDE.md` is a 5-line pointer to AGENTS.md).
- P-4 → drop (68 packages; linear scan ~µs).
- P-5 → drop (1 s sleep deliberately guards GitHub secondary rate limits on maintainer-only command).

## Stale evidence symbols to fix in BACKLOG.md

S-4 `setup_path_windows` / `remove_from_path_windows`; S-8 `replace_exe_windows` /
`delete_executable_windows`; SI-3 `glob_match`; SI-9 `resolve_command_name`; IM-13 `detect_editor`;
CL-6 `info.rs` `display_package_info`; CL-4 `generate_default_file`; P-4 `resolve_from_cache`.

## Verification caveat

S-6, S-8, S-4 are Windows-only; this Mac cannot run the real binary for them. Options: Windows VM,
or a CI-only check, or ship with "Pending verification" rows.

## New finding during IM-7 (2026-09-23) — not yet in BACKLOG, needs report + approval

`commands/add.rs` `run` and `commands/delete.rs` `run`/`delete_self` build `WenPaths::new()` instead
of using `config.paths()`, so `custom_bin_path` from config.toml is ignored by add/delete (launchers
go to default bin dir) while repair/rename/init honour it. Repro: config.toml
`custom_bin_path = "/abs/dir"`, `wenget add` a local script → launcher not in /abs/dir.
