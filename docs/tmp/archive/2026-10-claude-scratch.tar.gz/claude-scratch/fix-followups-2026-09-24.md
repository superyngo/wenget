## 2026-09-24
- `add -y fastfetch` (macos-aarch64 has .tar.gz and .zip of the same build) installs both under the
  same key: summary "2 package(s) installed: fastfetch fastfetch". Same in pre-158afd5 binary
  (pre-existing). Candidate bug, not fixed.
- Worktree /tmp/wg-pre158 (158afd5~1) + /tmp/wg-pre158-target left in place (not removed).
- `list` prints a package's `[Command: ...]` names in random order per run (fastfetch: 4 commands).
  Pre-existing HashMap order, cosmetic. Candidate fix: sort. Not fixed.

### Diagnosis (2026-09-24, awaiting approval)
- Lint: `#![warn(clippy::too_many_lines)]` added in src/main.rs (8c0cea4).
- Same-variant duplicates: `add::select_packages_for_platform` with `--yes` in add mode selects every
  binary from `filter_binaries`. fastfetch macos-aarch64 ships `.tar.gz` + `.zip`; both give
  `extract_variant_from_asset` = None -> key `fastfetch`, second install overwrites first.
  Update path: `normalize_asset_for_matching` strips extensions, so both match the stored template ->
  spurious "Could not determine exact binary" warning. Planned fix: after `filter_binaries` in
  `add::prepare_plan_binaries`, keep one binary per variant key (highest `FileExtension::format_score`,
  ties keep manifest order); unit test on the collapse helper.
- `[Command: …]` order: `InstalledPackage::get_command_names` iterates `executables: HashMap`.
  Planned fix: sort the returned names (all display sites: list/info/del).
