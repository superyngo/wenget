# Plan: "fix them all" (2026-09-24) — awaiting go-ahead

Baseline: HEAD 53eb8f2 (in sync with origin/main, tree clean).

## 1. B-11 `del` nondeterministic plan order / group label (bug)
- Symptom: with `bun` + `bun::profile` installed, `wenget del bun` prints the group as
  `bun (all variants)` on one run and `bun::profile (all variants)` on another; the variant rows
  and the repo order (`del 'rip*' bun`) swap between runs, deletion order follows. The MultiSelect
  prompt shows the same label ("Found 2 variant(s) of 'bun::profile'").
- Layer: `commands/delete.rs` `match_installed` + `group_delete_candidates`;
  `core::manifest::InstalledSet::find_by_repo`.
- Root cause: `InstalledSet.packages` is a std `HashMap` (per-process random order).
  `match_installed` returns keys in that order; `group_delete_candidates` labels a repo-level
  group with the first matched key instead of the repo; `find_by_repo` also yields HashMap order.
- Evidence: CL-6 parity diff (934eede vs 41dcc85, same logic) swapped label and rows; the existing
  test `test_repo_request_expands_to_all_variants_once` already sorts to dodge the order.
- Fix: sort `match_installed` output; label repo-level groups with `pkg.repo_name` (key prefix
  before `::` when a legacy record has none); sort each group's variant keys. A specific
  `name::variant` request keeps its key as label.
- Test: unit test passing matches as `["opencode::desktop.app", "opencode"]` expects
  `[("opencode", ["opencode", "opencode::desktop.app"])]` (fails on current code deterministically);
  `match_installed` returns sorted keys.
- Real binary: sandbox with `regclient` variants (regbot/regctl/regsync, ~35 MB); `del regclient`
  without `-y` and without a TTY prints the plan then stops at MultiSelect. 10 runs: old binary
  >1 distinct output, new binary exactly 1, label `regclient`.

## 2. CHANGELOG entry for "Using cached download links"
- Finding: before 158afd5 the planning phase silently fell back to the cached bucket package when
  the GitHub API failed, and the install phase then took the "already resolved" branch, so the
  warning was effectively unreachable. Since 158afd5 (`installer::package::target_package` →
  `TargetStatus::Cached`) `add`/`update` print "⚠ Using cached download links (GitHub API
  unavailable)" + "ℹ Falling back to bucket source download links" and skip re-caching.
  The 158afd5 changelog line only says "release is chosen once".
- Verify: build 158afd5~1 in a /tmp worktree; `add -y <small pkg>` with
  `WENGET_GITHUB_API=http://127.0.0.1:9` on old vs HEAD binary; expect warning only on HEAD.
- Then add a `fix(add)`-style changelog line under `### 2026-09-24`.

## 3. CL-9 remaining clippy `too_many_lines` (>100) functions — 13
`cargo clippy --all-targets -- -W clippy::too_many_lines`:
- add.rs: `install_scripts`, `plan_packages`, `install_plan_item`
- update.rs: `run`, `find_upgradeable`, `upgrade_self_with_provider`
- installer/package.rs: `PackageInstaller::install`, `select_executables`
- installer/extractor.rs: `find_executable_candidates`
- delete.rs: `delete_self`; bucket.rs: `run_create`; repair.rs: `run`; search.rs: `run`
Approach: pure extraction along the existing phase comments (compute vs print), no behavior
change. One commit per file group (add / update / installer / delete+bucket+repair+search).
Verify per commit: gate, clippy lint count drops, real-binary parity vs a baseline built from
53eb8f2 (scenario scripts per command; `update` via the `tests/update.rs` fixture path),
Windows-only branches (`delete_self`, self-update replace) via CI.
Option: add `#![warn(clippy::too_many_lines)]` so CI `-D warnings` keeps it at zero.

## Order
1 → 2 → 3, each: code + CHANGELOG + BACKLOG row, commit, docs(backlog) commit, push, CI 5/5.

## Status (2026-09-24)
Done: B-11 cf8b107, changelog f5cb25e, CL-9 35f91f2..1a8744a (backlog 30b3dbb). CI 5/5. Lint attribute not added (no answer). Worktrees /tmp/wg-cl9-*, /tmp/wg-pre158 and branches cl9-* left in place.
