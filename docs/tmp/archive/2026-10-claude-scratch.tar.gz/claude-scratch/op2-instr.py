import sys
root=sys.argv[1]; mode=sys.argv[2]
p=root+'/src/core/config.rs'; s=open(p).read()
a='    pub fn load_cache(&self) -> Result<ManifestCache> {\n'
b='    pub fn load_installed(&self) -> Result<InstalledSet> {\n'
m1='        eprintln!("@@LOAD_CACHE");\n'; m2='        eprintln!("@@LOAD_INSTALLED");\n'
if mode=='on': s=s.replace(a,a+m1,1).replace(b,b+m2,1)
else: s=s.replace(m1,'').replace(m2,'')
open(p,'w').write(s)
