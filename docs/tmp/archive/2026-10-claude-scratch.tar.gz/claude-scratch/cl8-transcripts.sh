#!/bin/bash
# Usage: cl8-transcripts.sh <wenget-bin> <out-file>
# Records CL-8 scenario transcripts in a fresh sandbox; paths normalized.
BIN=$1; OUT=$2
R=$(mktemp -d /tmp/wg-cl8.XXXX)
export GITHUB_TOKEN=${GITHUB_TOKEN:-$(gh auth token)}
W() { env HOME=$R/h WENGET_ROOT=$R/root NO_COLOR=1 "$BIN" "$@" 2>&1 </dev/null; }
{
W bucket add wenget https://raw.githubusercontent.com/superyngo/wenget/refs/heads/main/bucket/manifest.json >/dev/null
echo "== add fd"; W add -y fd
echo "== add fd again"; W add -y fd
echo "== add -p"; W add -y -p linux-x86_64-musl ripgrep
echo "== update after downgrade"
sed -i '' 's/"version": "[^"]*"/"version": "10.0.0"/' $R/root/apps/fd/.wenget/package.json
W update -y fd
echo "== multi variant"; W add -y ${MV_PKG:-bun}
echo "== custom version"; W add -y --ver 10.1.0 fd
echo "== variant"; W add -y --variant ${MV_VARIANT:-baseline} --no-suffix -c bunb ${MV_PKG:-bun}
echo "== url"; W add -y https://github.com/sharkdp/bat
echo "== not found"; W add -y fdd
echo "== list"; W list
} | sed -e "s#$R#<R>#g" -e 's/[0-9.]* *[KMG]i\{0,1\}B[^ ]*//g' -e 's/in [0-9.]*m\{0,1\}s//g' > "$OUT"
echo "$R"
