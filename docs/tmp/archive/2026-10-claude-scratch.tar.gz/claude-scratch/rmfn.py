import sys,re
# usage: rmfn.py file "signature substring" [...]  — deletes item + preceding ///, #[...] lines, via brace matching
p=sys.argv[1]; L=open(p).read().split('\n')
for sig in sys.argv[2:]:
    idx=[i for i,l in enumerate(L) if sig in l]
    assert len(idx)==1,(sig,idx); i=idx[0]
    s=i
    while s>0 and re.match(r'\s*(///|#\[|//)',L[s-1]): s-=1
    d=0;j=i;seen=False
    while True:
        d+=L[j].count('{')-L[j].count('}'); seen|= '{' in L[j]
        if seen and d==0: break
        j+=1
    e=j+1
    if s>0 and L[s-1].strip()=='' and e<len(L) and L[e].strip()=='': e+=1
    del L[s:e]
open(p,'w').write('\n'.join(L))
