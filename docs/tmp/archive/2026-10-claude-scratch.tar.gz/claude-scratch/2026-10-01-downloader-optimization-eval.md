# 下載器優化評估（斷點續傳 / 切片多線 / 其他）— 2026-10-01

類型：Research/Consult。未改任何程式碼。

## 現況（`src/downloader/mod.rs::download_file`）

- 單一 GET、64 KiB buffer、`File::create(dest)` 直接寫最終路徑、indicatif 進度條。
- 無重試、無 Range、無續傳。中途斷線 → 回傳錯誤 → `CleanupGuard` 刪掉半檔 → 下次從 0 開始。
- 逾時：`shared_client()` 沒設 timeout，所以吃到 reqwest **blocking 預設 30s**
  （`reqwest-0.12.28/src/blocking/client.rs:1500`）。blocking 的語意是「連線+取得 header ≤30s」
  加上「每次 `read()` ≤30s」（`blocking/response.rs:440`），等同 stall timeout，不是總時長上限。
  行為可接受，但是隱性的：`utils/http.rs:9` 註解寫「no total timeout / callers set per-request
  timeouts」、BACKLOG SI-12 寫「downloader 使用 per-request timeout」，兩者都與實際不符。
- 呼叫端：`PackageInstaller::download_and_stage`（package.rs:380）、`add` 直接 URL（add.rs:549）、
  self-update（update.rs:892）。`add`/`update` 多套件是**逐一**下載+安裝（add.rs:837 迴圈）。
- 下載檔名 = `downloads_dir/asset_name`。循序執行時沒問題；**若改並行，不同套件同名資產
  （如 `linux-amd64.tar.gz`）會撞檔**，需改為每套件唯一路徑。
- checksum 在下載後重讀整檔計算（`checksum.rs:212`）。
- reqwest `default-features = false` → 沒開 `http2`，只走 HTTP/1.1：多段下載會是多條獨立 TCP，
  正好是繞過「每連線限速」所需要的。

## 實測資料

- bucket/manifest.json 1174 個資產變體：p50 14 MB、p90 133 MB、p99 265 MB、最大 574 MB；
  >100 MB 有 155 個。
- GitHub release 資產：302 → `release-assets.githubusercontent.com` 簽名 URL（`se=` 約 33 分鐘後過期），
  回應 `Accept-Ranges: bytes`、`ETag`、`Last-Modified`，`Range` 回 206 + `Content-Range`。
  → Range／續傳／多段都可行；續傳要**重打原始 github.com URL** 取新的簽名 URL，不可快取
  redirect 後的位址。
- 本機網路吞吐量（curl，同一個 68 MB 資產，20s 窗口）：1 連線 110 KiB/s、4 連線 1419 KiB/s、
  8 連線 3075 KiB/s。另一個資產 15s 窗口：1 連線 510 → 104 KiB/s、2 連線 296 KiB/s。
  → **變異很大**；有每連線限速的跡象，但樣本不足以下定論。動工前要重複測 N 次。
- 單連線 68 MB 在 300s 內沒下載完（curl 被逾時中止）。

## 方向評估

| # | 方向 | 效益 | 成本 / 風險 | 建議 |
|---|------|------|-------------|------|
| A | 行程內重試＋Range 續傳：讀取錯誤或 stall 時用 `Range: bytes=N-` + `If-Range: <etag>` 重打原始 URL；206 → 接續寫，200 → 從頭寫；指數退避，最多約 3 次。下載到 `.part`，完成並驗證長度後 rename。逾時改為明確設定。 | 高：大檔／不穩網路不再整包重來 | 低：約 100 行；用 `TcpListener` 假伺服器（http.rs 測試已有此模式）注入斷線來測 | **先做** |
| B | 跨行程續傳：失敗時保留 `.part` + sidecar（url、etag、total），下次執行接續 | 中：僅在大檔＋使用者重跑時有感 | 中：`CleanupGuard` 語意要拆（網路失敗留檔、checksum 失敗刪檔）、過期 part 清理（`repair`/cache）、兩個 wenget 行程同時寫要加鎖 | 選做，放最後 |
| C | 單檔切片多連線：探測 Range+長度 → `set_len` 預配置 → `thread::scope` 開 N 條（預設 4）各自 `write_at`（unix `FileExt` / windows `seek_write`）→ 合併進度；每段各自重試（重用 A）。<16 MB、無 `Accept-Ranges`、長度未知時退回單流。 | 高（若真的是每連線限速）：實測 4 連線約 3–13 倍，但變異大 | 中：約 250–400 行、不新增依賴（顧及 `opt-level="z"` 體積）；對 CDN 禮節保守（4 條，最多 8）；HTTP/1.1 才有效 | 第二或第三優先 |
| D | 跨套件並行下載：`add`/`update` 拆成「並行下載階段（3–4 個 worker，`MultiProgress`）」+「循序安裝階段」（候選選擇提示、staging 仍循序） | 高：`update` 多套件時；p50 只有 14 MB，多數情境瓶頸是「件數」而非單檔大小 | 中高：要重構 add.rs 的 plan/install 流程、錯誤回報、下載路徑唯一化（撞檔問題） | 與 C 二擇一先做，看痛點 |
| E | 小項：串流計算 SHA-256（免重讀；C 模式不適用）、驗證 `downloaded == content_length`、修正 http.rs 註解與 BACKLOG SI-12 | 低 | 極低 | 併入 A |

## 建議順序

A(+E) → 依主要痛點選 D（「update 一堆套件很慢」）或 C（「單一大套件很慢」）→ B 視需求。

## 待決問題

1. 主要痛點：多套件更新慢，還是單一大檔慢／常失敗？
2. 連線數要不要開放設定（config.toml / CLI 旗標），還是先用常數？
3. 重測吞吐量：每種連線數各跑 ≥5 次、跨不同時段，再決定 C 的預設值。
